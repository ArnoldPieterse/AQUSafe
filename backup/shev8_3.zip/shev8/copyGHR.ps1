#$sourceFolder="\\lsaucap001.anglo.local\wrkgroup\Technical Services\Monthly Geotechnical Hazard Reports\Dashboards\GHR Report\*"
#$targetFolder=".\public"
#Copy-Item -Path $sourceFolder -Destination $targetFolder -Recurse -force